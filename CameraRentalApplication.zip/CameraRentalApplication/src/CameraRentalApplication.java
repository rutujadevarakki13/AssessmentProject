import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CameraRentalApplication {

    private static List<RentalCamera> cameraList = new ArrayList<>();
    private static User currentUser;


    public static void main(String[] args) {
    	
        System.out.println("WELCOME TO CAMERA RENTAL APPLICATION");
        System.out.println("PLEASE LOGIN TO CONTINUE");
        
        User admin = new User("username", "password");

        if (!login(admin)) {
            System.out.println("INVALID USERNAME OR PASSWORD.");
            return;
        }
        
        populateCameraList();
        
        displayMainMenu();
    }
    
    private static boolean login(User user) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("USERNAME: ");
        String username = scanner.nextLine();
        System.out.print("PASSWORD: ");
        String password = scanner.nextLine();

        if (username.equals(user.getUsername()) && password.equals(user.getPassword())) {
            currentUser = user;
            return true;
        }

        return false;
    }

    private static void populateCameraList() {
        cameraList.add(new RentalCamera("Canon", "EOS 5D Mark IV", 50.0, true));
        cameraList.add(new RentalCamera("Nikon", "D850", 60.0, true));
        cameraList.add(new RentalCamera("Sony", "Alpha A7 III", 70.0, true));

    }

    private static void displayMainMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. MY CAMERAS");
            System.out.println("2. RENT A CAMERA");
            System.out.println("3. VIEW ALL CAMERAS ");
            System.out.println("4. MY WALLET");
            System.out.println("5. EXIT");
            System.out.print("ENTER YOUR CHOICE: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                	myCamera();
                    break;
                case 2:
                    rentCamera();
                    break;
                case 3:
                	viewAllCameras();
                    break;     
                case 4:
                    manageWallet();
                    break;
                case 5:
                        System.out.println("THANK YOU FOR USING THE APPLICATION. ");
                        System.exit(0);
                    default:
                        System.out.println("INVALID CHOICE. PLEASE TRY AGAIN.");
            }
        }
    }
    private static void addCamera() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("ENTER THE BRAND OF THE CAMERA: ");
        String brand = scanner.nextLine();

        System.out.print("ENTER THE MODEL OF THE CAMERA: ");
        String model = scanner.nextLine();

        System.out.print("ENTER THE RENTAL AMOUNT PER DAY: ");
        double rentalAmount = scanner.nextDouble();
        scanner.nextLine(); 

        RentalCamera newCamera = new RentalCamera(brand, model, rentalAmount, true);
        cameraList.add(newCamera);

        System.out.println("CAMERA ADDED SUCCESSFULLY TO THE LIST.");
        viewAllCameras();
    }

    private static void removeCamera() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("ENTER THE CAMERA ID TO BE REMOVED: ");
        int cameraNumber = scanner.nextInt();
        scanner.nextLine(); 

        if (cameraNumber < 1 || cameraNumber > cameraList.size()) {
            System.out.println("INVALID CAMERA ID.");
            return;
        }

        RentalCamera removedCamera = cameraList.remove(cameraNumber - 1);
        System.out.println("CAMERA " + removedCamera.getBrand() + " " + removedCamera.getModel() + " REMOVED SUCCESSFULLY FROM THE LIST.");
        viewAllCameras();
    }

    private static void viewMyCameras() {
    	  viewAllCameras();
    	  }


    private static void myCamera() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- MY CAMERA ---");
            System.out.println("1. ADD A NEW CAMERA");
            System.out.println("2. REMOVE AN EXISTING CAMERA");
            System.out.println("3. VIEW MY CAMERAS");
            System.out.println("4. RETURN TO THE MAIN MENU");
            System.out.print("ENTER YOUR CHOICE: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addCamera();
                    break;
                case 2:
                    removeCamera();
                    break;
                case 3:
                    viewMyCameras();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("INVALID CHOICE. PLEASE TRY AGAIN.");
            }
        }
        
    }

    private static void rentCamera() {
        Scanner scanner = new Scanner(System.in);
        viewAllCameras();

        System.out.print("ENTER THE CAMERA ID TO BE RENTED: ");
        int cameraNumber = scanner.nextInt();
        scanner.nextLine();

        if (cameraNumber < 1 || cameraNumber > cameraList.size()) {
            System.out.println("INVALID CAMERA ID.");
            return;
        }

        RentalCamera selectedCamera = cameraList.get(cameraNumber - 1);

        if (!selectedCamera.isAvailable()) {
            System.out.println("CAMERA IS CURRENLY NOT AVAILABLE FOR RENT.");
            return;
        }

        double rentalAmount = selectedCamera.getRentalAmount();

        if (currentUser.getWalletBalance() < rentalAmount) {
            System.out.println("INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT FUNDS.");
        } else {
            selectedCamera.setAvailable(false);
            currentUser.depositToWallet(-rentalAmount); 
            System.out.println("CAMERA " + selectedCamera.getBrand() + " " + selectedCamera.getModel() + " HAS BEEN RENTED SUCCESSFULLY.");
        }
    }
    
    private static void viewAllCameras() {
        System.out.println("\n--- ALL CAMERAS ---");
        System.out.println("==========================================================================================");
        System.out.printf("%-15s%-15s%-25sINR.%-20s%-5s\n", "CAMERA_ID.", "BRAND", "MODEL", "RENT(PER DAY)", "STATUS");
        System.out.println("==========================================================================================");


        if (cameraList.isEmpty()) {
            System.out.println("NO CAMERAS AVAILABLE.");
        } else {
        	 for (int i = 0; i < cameraList.size(); i++) {
                 RentalCamera camera = cameraList.get(i);
                 String status = camera.isAvailable() ? "Available" : "Not Available";
                 System.out.printf("%-15s%-15s%-25sINR.%-20s%-5s\n", i + 1, camera.getBrand(), camera.getModel(), camera.getRentalAmount(), status);
            }
        }
        System.out.println("==========================================================================================");
    }


    private static void manageWallet() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n--- WALLET MANAGEMENT ---");
        System.out.println("CURRENT WALLET BALANCE: INR." + currentUser.getWalletBalance());

        System.out.print("DEPOSIT FUNDS? (YES/NO): ");
        String response = scanner.nextLine();

        if (response.equalsIgnoreCase("yes")) {
            System.out.print("ENTER THE AMOUNT TO BE DEPOSITED: ");
            double amount = scanner.nextDouble();
            scanner.nextLine();
            currentUser.depositToWallet(amount);
            System.out.println("FUNDS DEPOSITED SUCCESSFULLY. CURRENT WALLET BALANCE - INR." + currentUser.getWalletBalance());
        } else {
            System.out.println("NO FUNDS DEPOSITED.");
        }
    }
}