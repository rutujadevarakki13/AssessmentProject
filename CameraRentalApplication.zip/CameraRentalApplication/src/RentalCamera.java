class RentalCamera extends Camera {
    private boolean available;

    public RentalCamera(String brand, String model, double rentalAmount, boolean available) {
        super(brand, model, rentalAmount);
        this.available = available;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

class User {
    private String username;
    private String password;
    private double walletBalance;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.walletBalance = 1000.0;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public double getWalletBalance() {
        return walletBalance;
    }

    public void depositToWallet(double amount) {
        walletBalance += amount;
    }
}